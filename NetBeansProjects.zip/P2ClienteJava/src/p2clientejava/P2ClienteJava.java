/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p2clientejava;

import java.util.Scanner;
import validar.Persona;
import validar.Validar_Service;


/**
 *
 * @author y9d1ru
 */
public class P2ClienteJava {

    /**
     * @param args the command line arguments
     */
        static Scanner scanner;
        static Validar_Service vs = new Validar_Service();

    public static void main(String[] args) {

        scanner = new Scanner(System.in);
        
        crearMenu();
    }

    
    public static void crearMenu() {
        System.out.println("1. Añadir contacto");
        System.out.println("2. Guardar");
        System.out.println("3. Validar XSD");
//        System.out.println("4. Importar persona");
//        System.out.println("5. Exportar persona");
//        System.out.println("6. Contar personas en la agenda (XPath)");
//        System.out.println("7. ¿Que personas tienen el telefono 1234?");
        System.out.println("4. Salir");
        int opcion = scanner.nextInt();
        comprobar(opcion);
    }

    public static void comprobar(int opcion) {
        switch (opcion) {
            case 1:
                crearContacto();
                break;
//            case 2:
//                guardar();
//                break;
            case 3:
                validarXSD();
                break;
//            case 4:
//                importarPersona();
//                break;
//            case 5:
//                exportarPersona();
//                break;
//            case 6:
//                evaluarXpath();
//                break;
//            case 7:
//                xQueryEvaluador();
//                break;
            case 4:
                System.exit(0);
        }
    }

    
    public static void crearContacto() {
        System.out.println("Introduzca el nombre:");
        String nombre = scanner.next();
        String restriccionEmail = "[_\\-a-zA-z0-9\\.\\+]+@[a-zA-z0-9](\\.?[\\-a-zA-z0-9]*[a-zA-z0-9])*";
//        while(!nombre.matches("")){
//            System.out.println("Por favor, introduzca un nombre valido");
//            nombre = scanner.next();
//        }
//        nada, los nombres no tenían restricicones
        System.out.println("Introduzaca el numero de telefono:");
        String telefono = scanner.next();
        System.out.println("Introduzca el email:");
        String email = scanner.next();
        while(!email.matches(restriccionEmail) && email.length()<255){
            System.out.println("Por favor, introduzca un email válido");
            email = scanner.next();
        }
        Persona p = new Persona();
        p.setNombre(nombre);
        p.setTelefono(telefono);
        p.setEmail(email);
        System.out.println(vs.getValidarPort().crearContacto(p));
        crearMenu();
    }
//
//    private static void guardar() {
//        System.out.println(vs.getValidarPort());
//        
//    }

    private static void validarXSD() {
            
                if(vs.getValidarPort().validateAgenda()){
                    System.out.println("La agenda es válida");
                }else{
                    System.out.println("La agenda NO es válida");
                }
            crearMenu();
    }
    
}
