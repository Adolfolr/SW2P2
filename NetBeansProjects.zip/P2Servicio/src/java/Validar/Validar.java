/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Validar;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;
import org.xml.sax.SAXException;
import p2Package.Agenda;
import p2Package.Metodos;
import p2Package.Persona;
import sun.misc.Launcher;

/**
 *
 * @author y9d1ru
 */
@WebService(serviceName = "Validar")
public class Validar {

    /**
     * This is a sample web service operation
     */
    @Resource
    private WebServiceContext wsContext;
    static Agenda agenda = new Agenda();
    
    @WebMethod(operationName = "validateAgenda")
    public boolean validateAgenda()  {
        try {

            SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            HttpServletRequest servRequest = (HttpServletRequest) wsContext.getMessageContext().
                    get(MessageContext.SERVLET_REQUEST);

            HttpSession session = (HttpSession) servRequest.getSession();

            ServletContext servletContext = session.getServletContext();
            URL resource = null;
            JAXBContext jAXBContext = JAXBContext.newInstance(Agenda.class);
            Marshaller marshaller = jAXBContext.createMarshaller();
            try {
                resource = servletContext.getResource("/Agenda.xsd");
            } catch (MalformedURLException ex) {
                Logger.getLogger(Agenda.class.getName()).log(Level.SEVERE, null, ex);
            }

            Schema schema = sf.newSchema(resource);

            marshaller.setSchema(schema);
            
            Metodos met = new Metodos();
            Agenda age = met.importar("Agenda.xml");
            marshaller.marshal(age, System.out);
            
            
            return true;

        } catch (SAXException ex) {
            Logger.getLogger(Launcher.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JAXBException ex) {
            Logger.getLogger(Validar.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    @WebMethod(operationName = "CrearContacto")
    public String crearContacto(Persona persona){
        agenda.anadirPersona(persona);
        return "Persona añadida correctamente";
    }
    
    @WebMethod(operationName = "Guardar")
    public String guardarAgenda(){
        Metodos met = new Metodos();
        met.guardar(agenda);
        return "Agenda guardada";
    }
}
